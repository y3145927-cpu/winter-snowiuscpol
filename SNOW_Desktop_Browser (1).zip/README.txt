SNOW Desktop Browser (Electron)
================================

This is a desktop browser starter, not just a web page. It uses Electron's Chromium webview to display websites INSIDE SNOW tabs.

REQUIREMENTS
- Windows 10/11
- Node.js LTS installed from https://nodejs.org
- Internet connection

RUN IT
1. Extract the ZIP to a folder.
2. Open a terminal / Command Prompt in that folder.
3. Run: npm install
4. Run: npm start

OPTIONAL: Build a Windows app folder
- Run: npm run pack
- The packaged app folder is created by electron-packager.

WHAT WORKS
- Internal tabs and in-app website views via Electron webview
- Back, forward, reload, address/search bar
- Internal bookmarks and history stored in localStorage
- Settings for background color, ultraviolet accent and particle cursor
- Live clock/date
- Music search links and Snow AI demo interface

LIMITS / SECURITY
- This is a starting desktop browser, not a production-hardened browser.
- No proxy is configured by default. It does not hide your IP or bypass network restrictions. A proxy requires a legitimate proxy endpoint and careful security configuration; do not enter unknown proxy credentials.
- Snow AI is demo-only until you connect a model/API.
- Music cards search YouTube Music; SNOW does not host tracks.
- Electron's webview is deprecated for some use cases and needs a security review before public distribution. Do not browse untrusted sites with sensitive accounts in this prototype.
