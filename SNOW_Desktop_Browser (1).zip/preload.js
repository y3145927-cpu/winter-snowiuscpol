const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('snowDesktop', {
  version: () => ipcRenderer.invoke('snow:version')
});
